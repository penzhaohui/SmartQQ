﻿// mytest.js 
var VS_STRING_REFRESH = "刷新";
var VS_PAGE_LOADING = "页面加载中...";

var VS_MENUITEMICON= "";
var VS_MENUITEMICON1= "txfile:platformres:MyService/img/miicon1.gif";
