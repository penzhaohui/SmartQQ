﻿// window.js 
var VS_BLANK_CONTENT = "请在空白区域点击鼠标右键，选择您要显示的服务。";
var VS_BROWSERLOWVER = "对不起，您的浏览器版本过低！\n建议您使用新版本浏览器！谢谢！";
var VS_TIPS_REFRESH =  "刷新";


var IMG_WINDOW_TIP =  "txfile:platformres:MyService/img/tip.gif";

var IMG_EXPAND = "txfile:platformres:MyService/img/expand.gif";
var IMG_COLLAPSE = "txfile:platformres:MyService/img/collapse.gif";
var IMG_CLOSE = "txfile:platformres:MyService/img/close.gif";
var IMG_DIVLOGO =  "txfile:platformres:MyService/img/logo.gif";
var IMG_WINDOW_REFRESH = "txfile:platformres:MyService/img/refurbish.gif";
var IMG_WINDOW_EDIT =  "txfile:platformres:MyService/img/add.gif";
var TYPE_LOGO = 1;
var TYPE_TOGGLE = 2;
var TYPE_REFRESH = 3;





