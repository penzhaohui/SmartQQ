﻿using System;
using System.Collections.Generic;
using System.Text;
using CCWin.SkinControl;

namespace CC2013
{
    public class UserLogin
    {
        public static ChatListSubItem UserItem;
    }
}
